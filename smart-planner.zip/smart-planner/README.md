# smart-planner
Smart Planner. O aplicație web care ajută utilizatorii să își planifice și să își îndeplinească obiectivele zilnice.
