/* =========================================
   1. GESTIONARE UTILIZATORI (AUTH)
   ========================================= */

const currentPage = window.location.pathname.split("/").pop();
const publicPages = ["login.html", "signup.html", "welcome.html"];
let loggedUser = JSON.parse(localStorage.getItem("loggedUser"));

// Asigură-te că userul are un plan setat (Default: Basic)
if (loggedUser && !loggedUser.plan) {
    loggedUser.plan = "Basic";
    localStorage.setItem("loggedUser", JSON.stringify(loggedUser));
}

// Redirecționare
if (!loggedUser && !publicPages.includes(currentPage) && currentPage !== "") {
    window.location.href = "welcome.html";
}

// LOGOUT
const logoutBtn = document.getElementById("logout-btn");
if (logoutBtn) {
    logoutBtn.addEventListener("click", () => {
        localStorage.removeItem("loggedUser");
        window.location.href = "welcome.html";
    });
}

// SIGNUP
const signupForm = document.getElementById("signupForm");
if (signupForm) {
    signupForm.addEventListener("submit", (e) => {
        e.preventDefault();
        const name = signupForm.querySelector('input[type="text"]').value;
        const email = signupForm.querySelector('input[type="email"]').value;
        const password = signupForm.querySelector('input[type="password"]').value;

        let users = JSON.parse(localStorage.getItem("users")) || [];
        if (users.find(u => u.email === email)) {
            alert("Acest email este deja folosit!");
            return;
        }
        // Utilizator nou (Plan default: Basic)
        users.push({ name, email, password, xp: 0, level: 1, plan: "Basic" });
        localStorage.setItem("users", JSON.stringify(users));
        alert("Cont creat cu succes! Te poți loga.");
        window.location.href = "login.html";
    });
}

// LOGIN
const loginForm = document.getElementById("loginForm");
if (loginForm) {
    loginForm.addEventListener("submit", (e) => {
        e.preventDefault();
        const email = loginForm.querySelector('input[type="email"]').value;
        const password = loginForm.querySelector('input[type="password"]').value;

        let users = JSON.parse(localStorage.getItem("users")) || [];
        const user = users.find(u => u.email === email && u.password === password);

        if (user) {
            // Asigură plan default la login
            if (!user.plan) user.plan = "Basic";
            localStorage.setItem("loggedUser", JSON.stringify(user));
            window.location.href = "index.html";
        } else {
            alert("Email sau parolă incorectă!");
        }
    });
}

/* =========================================
   2. GAMIFICATION & PLAN DISPLAY
   ========================================= */
function updateXP(amount) {
    if (!loggedUser) return;
    if (!loggedUser.xp) loggedUser.xp = 0;
    if (!loggedUser.level) loggedUser.level = 1;

    loggedUser.xp += amount;
    const xpNeeded = loggedUser.level * 100;
    
    if (loggedUser.xp >= xpNeeded) {
        loggedUser.xp = loggedUser.xp - xpNeeded;
        loggedUser.level++;
        alert(`🎉 FELICITĂRI! Ai ajuns la Nivelul ${loggedUser.level}!`);
    }
    saveUserData();
    renderGamification();
}

function saveUserData() {
    localStorage.setItem("loggedUser", JSON.stringify(loggedUser));
    let allUsers = JSON.parse(localStorage.getItem("users")) || [];
    const userIndex = allUsers.findIndex(u => u.email === loggedUser.email);
    if (userIndex !== -1) {
        allUsers[userIndex] = loggedUser;
        localStorage.setItem("users", JSON.stringify(allUsers));
    }
}

function renderGamification() {
    const levelSpan = document.getElementById("user-level");
    const xpSpan = document.getElementById("current-xp");
    const nextXpSpan = document.getElementById("next-level-xp");
    const xpBar = document.getElementById("xp-bar");
    const title = document.getElementById("level-title");
    const planSpan = document.getElementById("user-current-plan");

    if (!levelSpan || !loggedUser) return;

    const currentLevel = loggedUser.level || 1;
    const currentXP = loggedUser.xp || 0;
    const xpNeeded = currentLevel * 100;

    levelSpan.innerText = currentLevel;
    xpSpan.innerText = currentXP;
    nextXpSpan.innerText = xpNeeded;
    const percentage = (currentXP / xpNeeded) * 100;
    xpBar.style.width = `${percentage}%`;

    const titles = ["Începător", "Harnic", "Organizator", "Maestru", "Productivity God 🚀"];
    title.innerText = titles[Math.min(currentLevel - 1, titles.length - 1)];

    // AFIȘARE PLAN CURENT IN SIDEBAR
    if (planSpan) {
        planSpan.innerText = loggedUser.plan || "Basic";
    }

    // UPDATE CARDURI VIZUAL (Highlight Plan Activ)
    highlightActivePlan();
}

function highlightActivePlan() {
    const cards = document.querySelectorAll(".card");
    const currentPlan = loggedUser.plan || "Basic";

    cards.forEach(card => {
        card.classList.remove("active-plan"); // Reset
        const cardPlan = card.getAttribute("data-plan");
        if (cardPlan === currentPlan) {
            card.classList.add("active-plan"); // Adaugă bordură verde
        }
    });
}

// Apelăm funcția la încărcare
renderGamification();

/* =========================================
   3. GESTIONARE TASK-URI & XP VARIABIL
   ========================================= */
const userTasksKey = loggedUser ? `tasks_${loggedUser.email}` : "temp_tasks";
let tasks = JSON.parse(localStorage.getItem(userTasksKey)) || [];

const taskInput = document.getElementById("task-input");
const taskDate = document.getElementById("task-deadline");
const taskCategory = document.getElementById("task-category");
const taskPriority = document.getElementById("task-priority");
const addBtn = document.getElementById("add-btn");
const taskList = document.getElementById("task-list");
const filterCategory = document.getElementById("filter-category");
const filterPriority = document.getElementById("filter-priority");

if (taskList && loggedUser) {
    const headerTitle = document.querySelector("header h1");
    if(headerTitle) headerTitle.innerHTML = `🧠 Smart Planner <br><small style="font-size:0.4em; font-weight:normal;">Salut, ${loggedUser.name}!</small>`;
    
    renderTasks();

    addBtn.addEventListener("click", () => {
        const text = taskInput.value.trim();
        const date = taskDate.value;
        const category = taskCategory.value;
        const priority = taskPriority.value;
        if (!text) return alert("Scrie un task!");

        tasks.push({ text, date, category, priority, completed: false });
        saveTasks();
        renderTasks();
        taskInput.value = "";
        taskDate.value = "";
    });

    filterCategory?.addEventListener("change", renderTasks);
    filterPriority?.addEventListener("change", renderTasks);
}

function renderTasks() {
    if (!taskList) return;
    taskList.innerHTML = "";

    tasks.forEach((task, index) => {
        if (filterCategory.value !== "All" && task.category !== filterCategory.value) return;
        if (filterPriority.value !== "All" && task.priority !== filterPriority.value) return;

        const li = document.createElement("li");
        li.dataset.priority = task.priority;
        if (task.completed) li.classList.add("completed");

        li.innerHTML = `
            <span style="flex:1;">
                <strong>${task.text}</strong> <br>
                <small>📅 ${task.date || "Fără dată"} | 📂 ${task.category} | 🔥 ${task.priority}</small>
            </span>
            <div style="display:flex; gap:10px;">
                <button class="complete-btn" style="background:none; border:none; cursor:pointer; font-size:1.2rem;">${task.completed ? '↩️' : '✅'}</button>
                <button class="delete-btn" style="background:none; border:none; cursor:pointer; font-size:1.2rem;">❌</button>
            </div>
        `;

        li.querySelector(".complete-btn").addEventListener("click", () => {
            task.completed = !task.completed;
            
            // LOGICĂ XP VARIABIL
            if (task.completed) {
                let xpAmount = 10; 
                if (task.priority === "High") xpAmount = 40;
                else if (task.priority === "Medium") xpAmount = 20;
                
                updateXP(xpAmount); 
            }

            saveTasks();
            renderTasks();
        });

        li.querySelector(".delete-btn").addEventListener("click", () => {
            if(confirm("Ștergi acest task?")) {
                tasks.splice(index, 1);
                saveTasks();
                renderTasks();
            }
        });
        taskList.appendChild(li);
    });
}

function saveTasks() { localStorage.setItem(userTasksKey, JSON.stringify(tasks)); }

/* =========================================
   4. POPUP & UPGRADE LOGIC (NOU)
   ========================================= */
const cards = document.querySelectorAll(".card");
const popup = document.getElementById("card-popup");
const popupTitle = document.getElementById("popup-title");
const popupDesc = document.getElementById("popup-description");
const popupAction = document.getElementById("popup-action-container");
const closePopup = document.querySelector(".popup .close");

const cardInfo = {
  Basic: {
      desc: "Planul perfect pentru început. Ai acces la lista de task-uri și funcții de bază.",
      price: "Gratuit"
  },
  Pro: {
      desc: "Pentru cei organizați. Deblochează statistici avansate și culori personalizate.",
      price: "5€ / lună"
  },
  Premium: {
      desc: "Experiența completă. Prioritate la suport, teme exclusive și funcții nelimitate.",
      price: "10€ / lună"
  }
};

if (cards.length > 0) {
    cards.forEach(card => {
        card.addEventListener("click", () => {
            const planName = card.getAttribute("data-plan"); // Basic, Pro, Premium
            const info = cardInfo[planName];
            
            popupTitle.textContent = `${planName} - ${info.price}`;
            popupDesc.textContent = info.desc;
            
            // LOGICA DE BUTON (UPGRADE SAU ACTIV)
            const currentPlan = loggedUser.plan || "Basic";
            
            if (currentPlan === planName) {
                // Planul este deja activ
                popupAction.innerHTML = `<button class="upgrade-btn current" disabled>Plan Actual ✅</button>`;
            } else {
                // Planul poate fi cumpărat (Upgrade sau Downgrade)
                popupAction.innerHTML = `<button class="upgrade-btn available" id="btn-upgrade">Upgradează la ${planName} 🚀</button>`;
                
                // Adăugăm event listener pentru upgrade
                document.getElementById("btn-upgrade").addEventListener("click", () => {
                    if(confirm(`Ești sigur că vrei să treci la planul ${planName}?`)) {
                        loggedUser.plan = planName;
                        saveUserData(); // Salvăm în localStorage
                        renderGamification(); // Actualizăm UI-ul
                        popup.style.display = "none";
                        alert(`Succes! Contul tău este acum ${planName}.`);
                    }
                });
            }

            popup.style.display = "block";
        });
    });

    closePopup?.addEventListener("click", () => popup.style.display = "none");
    window.addEventListener("click", (e) => { if (e.target === popup) popup.style.display = "none"; });
}

/* =========================================
   5. ALTELE (Stats, Calendar, DarkMode)
   ========================================= */
const ctx = document.getElementById('progressChart');
if (ctx) {
    const completedCount = tasks.filter(t => t.completed).length;
    const activeCount = tasks.length - completedCount;
    const categories = ["Personal", "Muncă", "Studii"];
    const categoryData = categories.map(cat => tasks.filter(t => t.category === cat).length);
    new Chart(ctx, {
        type: 'doughnut', 
        data: {
            labels: ['Finalizate', 'Active', ...categories],
            datasets: [{
                label: 'Status', data: [completedCount, activeCount, 0, 0, 0],
                backgroundColor: ['#4caf50', '#ff9800', '#eee', '#eee', '#eee'], borderWidth: 1
            }, {
                label: 'Categorii', data: [0, 0, ...categoryData],
                backgroundColor: ['transparent', 'transparent', '#3f2b96', '#E91E63', '#00bcd4'], borderWidth: 1
            }]
        }, options: { responsive: true }
    });
}

const calendarView = document.getElementById("calendar-view");
if (calendarView) {
    if (tasks.length === 0) {
        calendarView.innerHTML = "<p style='text-align:center;'>Nu ai task-uri adăugate.</p>";
    } else {
        const sortedTasks = [...tasks].sort((a, b) => new Date(a.date) - new Date(b.date));
        let currentGroupDate = null;
        sortedTasks.forEach(task => {
            if (!task.date) return;
            if (task.date !== currentGroupDate) {
                currentGroupDate = task.date;
                const dateHeader = document.createElement("h3");
                dateHeader.style.marginTop = "20px"; dateHeader.style.color = "#3f2b96"; dateHeader.innerText = `📅 ${task.date}`;
                calendarView.appendChild(dateHeader);
            }
            const div = document.createElement("div");
            div.className = "calendar-task";
            div.style.background = task.completed ? "#e0e0e0" : "#fff";
            div.style.padding = "10px"; div.style.border = "1px solid #ccc"; div.style.borderRadius = "8px"; div.style.marginBottom = "5px"; div.style.display = "flex"; div.style.justifyContent = "space-between"; div.style.color = "#333";
            div.innerHTML = `<span>${task.text}</span> <small>${task.priority}</small>`;
            calendarView.appendChild(div);
        });
    }
}
// Dark Mode
const modeToggle = document.getElementById("mode-toggle");
if (localStorage.getItem("darkMode") === "true") document.body.classList.add("dark-mode");
if (modeToggle) {
    modeToggle.addEventListener("click", () => {
        document.body.classList.toggle("dark-mode");
        localStorage.setItem("darkMode", document.body.classList.contains("dark-mode"));
    });
}
const notesArea = document.getElementById("notes");
if (notesArea) {
    const notesKey = `notes_${loggedUser ? loggedUser.email : 'guest'}`;
    notesArea.value = localStorage.getItem(notesKey) || "";
    notesArea.addEventListener("input", () => localStorage.setItem(notesKey, notesArea.value));
}