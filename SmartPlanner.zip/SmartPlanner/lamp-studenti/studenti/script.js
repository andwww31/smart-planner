/* =========================================
   1. POPUP & UPGRADE PLANURI
   ========================================= */
const plansData = {
    Basic: {
        price: "Gratuit",
        features: ["✅ Acces la Task-uri", "✅ Calendar Simplu", "❌ Fără Statistici Avansate", "❌ Fără Suport Prioritar"]
    },
    Pro: {
        price: "5€ / lună",
        features: ["✅ Acces la Task-uri", "✅ Calendar Avansat", "✅ Statistici Detaliate", "❌ Fără Suport Prioritar"]
    },
    Premium: {
        price: "10€ / lună",
        features: ["✅ Totul Nelimitat", "✅ Teme Exclusive", "✅ Statistici Pro", "✅ Suport Prioritar 24/7"]
    }
};

// Elemente HTML
const modal = document.getElementById("plan-popup");
const closeBtn = document.querySelector(".close-btn");
const cards = document.querySelectorAll(".card"); 

// Logica de click pe carduri (Doar dacă există carduri în pagină)
if (cards.length > 0) {
    cards.forEach(card => {
        card.addEventListener("click", () => {
            // Găsim numele planului (Basic, Pro sau Premium) din titlul h3
            const planTitle = card.querySelector("h3");
            if (!planTitle) return; // Siguranță

            const planName = planTitle.innerText.trim();
            const data = plansData[planName];

            if (data) {
                // 1. Populăm Titlul și Prețul
                const titleEl = document.getElementById("popup-title");
                const priceEl = document.getElementById("popup-price");
                const inputEl = document.getElementById("selected-plan-input");
                const listEl = document.getElementById("popup-features");
                const btnEl = document.getElementById("popup-action-btn");

                if(titleEl) titleEl.innerText = planName + " Plan";
                if(priceEl) priceEl.innerText = data.price;
                if(inputEl) inputEl.value = planName;

                // 2. Generăm lista de beneficii
                if (listEl) {
                    listEl.innerHTML = ""; // Curățăm lista veche
                    data.features.forEach(feat => {
                        let li = document.createElement("li");
                        li.innerText = feat;
                        li.style.listStyle = "none"; 
                        li.style.marginBottom = "5px";
                        li.style.fontSize = "0.95rem";
                        listEl.appendChild(li);
                    });
                }

                // 3. Verificăm butonul (Dacă userul are deja planul activ)
                // Luăm planul curent direct din textul afișat de PHP în sidebar
                const currentPlanElement = document.getElementById("user-current-plan");
                const currentPlan = currentPlanElement ? currentPlanElement.innerText.trim() : "Basic";

                if (btnEl) {
                    if (currentPlan === planName) {
                        btnEl.innerText = "Plan Activ ✅";
                        btnEl.disabled = true;
                        btnEl.style.opacity = "0.6";
                        btnEl.style.cursor = "not-allowed";
                    } else {
                        btnEl.innerText = `Activează ${planName}`;
                        btnEl.disabled = false;
                        btnEl.style.opacity = "1";
                        btnEl.style.cursor = "pointer";
                    }
                }

                // 4. Afișăm fereastra
                if(modal) modal.style.display = "block";
            }
        });
    });
}

// Închidere Popup la click pe X
if (closeBtn) {
    closeBtn.onclick = () => modal.style.display = "none";
}

// Închidere Popup la click în afara ferestrei
window.onclick = (event) => {
    if (event.target == modal) modal.style.display = "none";
}

/* =========================================
   2. DARK MODE
   ========================================= */
const modeToggle = document.getElementById("mode-toggle");

// Verificăm preferința salvată
if (localStorage.getItem("darkMode") === "true") {
    document.body.classList.add("dark-mode");
}

if (modeToggle) {
    modeToggle.addEventListener("click", () => {
        document.body.classList.toggle("dark-mode");
        // Salvăm preferința în browser
        localStorage.setItem("darkMode", document.body.classList.contains("dark-mode"));
    });
}

/* =========================================
   3. NOTIȚE RAPIDE (Sidebar)
   ========================================= */
const notesArea = document.getElementById("notes");
if (notesArea) {
    // Folosim un key generic sau bazat pe user dacă vrei să fie unic per browser
    const notesKey = "smart_planner_notes";
    notesArea.value = localStorage.getItem(notesKey) || "";
    
    notesArea.addEventListener("input", () => {
        localStorage.setItem(notesKey, notesArea.value);
    });
}