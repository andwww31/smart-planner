<?php
// Includem db.php pentru a porni sesiunea
require 'db.php';

// VERIFICARE LOGIN:
// Dacă utilizatorul este deja logat, îl trimitem direct la aplicație (index.php)
if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Smart Planner - Bine ai venit</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

  <nav class="navbar">
    <h2>Smart Planner</h2>
  </nav>

  <div class="container" style="text-align:center;">
    <h1>Bine ai venit la <span style="color:#3f2b96;">Smart Planner</span>!</h1>
    <p>Organizează-ți timpul, stabilește-ți obiectivele și atinge-ți scopurile mai ușor.</p>

    <div style="margin-top:30px; display:flex; justify-content:center; gap:20px;">
      <a href="login.php">
        <button style="background:#3f2b96; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer;">Loghează-te</button>
      </a>
      <a href="signup.php">
        <button style="background:#ff69b4; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer;">Creează cont</button>
      </a>
    </div>
  </div>

</body>
</html>