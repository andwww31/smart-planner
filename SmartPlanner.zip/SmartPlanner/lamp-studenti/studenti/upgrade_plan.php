<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['plan_name'])) {
    $new_plan = $_POST['plan_name'];
    $user_id = $_SESSION['user_id'];

    // Validăm ca planul să fie unul real
    $allowed_plans = ['Basic', 'Pro', 'Premium'];
    if (in_array($new_plan, $allowed_plans)) {
        
        // Actualizăm în baza de date
        $stmt = $pdo->prepare("UPDATE users SET plan = ? WHERE id = ?");
        
        if ($stmt->execute([$new_plan, $user_id])) {
            // Actualizăm și sesiunea ca să se vadă instant
            $_SESSION['plan'] = $new_plan; // (dacă folosești variabila asta undeva)
            
            // Ne întoarcem la index cu mesaj de succes (opțional, poți implementa mesaje)
            header("Location: index.php");
            exit();
        }
    }
}

// Dacă ceva nu merge, înapoi la index
header("Location: index.php");
exit();
?>