<?php
ob_start();
session_start();
require 'db.php';

// Verificare login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'] ?? 'User';

// Luăm task-urile ordonate după dată
$stmt = $pdo->prepare("SELECT * FROM tasks WHERE user_id = ? ORDER BY deadline ASC");
$stmt->execute([$user_id]);
$tasks = $stmt->fetchAll();

// Grupăm task-urile pe zile
$calendarData = [];
foreach ($tasks as $task) {
    $date = $task['deadline'] ? $task['deadline'] : 'Fără dată';
    $calendarData[$date][] = $task;
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
  <meta charset="UTF-8">
  <title>Calendar - Smart Planner</title>
  <link rel="stylesheet" href="style.css">
</head>
<body class="grid-page">
  <div class="grid-container">
    <header>
      <h1>📅 Calendarul Tău</h1>
      <a href="index.php" style="color: white; text-decoration: none;">⬅ Înapoi la Dashboard</a>
    </header>

    <nav>
      <ul>
        <li><a href="index.php">Task-uri</a></li>
        <li><a href="calendar.php" class="active">Calendar</a></li>
        <li><a href="stats.php">Statistici</a></li>
        <li><a href="about.php">Despre</a></li>
      </ul>
    </nav>

    <main>
      <div class="container">
        <h2>Agenda pe zile</h2>
        
        <?php if (empty($calendarData)): ?>
            <p>Nu ai task-uri planificate.</p>
        <?php else: ?>
            <div class="calendar-view">
                <?php foreach ($calendarData as $date => $dayTasks): ?>
                    <div class="day-group" style="margin-bottom: 20px;">
                        <h3 style="background: #eee; padding: 10px; border-radius: 5px; color: #333;">
                            <?php echo ($date === 'Fără dată') ? '📌 De făcut oricând' : '📅 ' . date("d.m.Y", strtotime($date)); ?>
                        </h3>
                        
                        <?php foreach ($dayTasks as $t): ?>
                            <div class="task-card" style="border-left: 4px solid <?php echo ($t['status'] === 'completed') ? 'green' : '#E91E63'; ?>; background: white; padding: 10px; margin: 5px 0; border-radius: 5px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                                <strong><?php echo htmlspecialchars($t['title']); ?></strong>
                                <span style="float: right; font-size: 0.8em;"><?php echo $t['priority']; ?></span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
      </div>
    </main>
  </div>
</body>
</html>