<?php
// 1. START SESIUNE
ob_start();
session_start();

// 2. VERIFICARE LOGIN
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

require 'db.php';
$user_id = $_SESSION['user_id'];


$stmtUser = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmtUser->execute([$user_id]);
$currentUser = $stmtUser->fetch();

if (!$currentUser) {
    session_destroy();
    header("Location: login.php");
    exit();
}

// 4. LISTA TASK-URI
$stmtTasks = $pdo->prepare("SELECT * FROM tasks WHERE user_id = ? ORDER BY deadline ASC, created_at DESC");
$stmtTasks->execute([$user_id]);
$tasks = $stmtTasks->fetchAll();

$xp_percentage = $currentUser['xp'] ?? 0; 
?>

<!DOCTYPE html>
<html lang="ro">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Smart Planner - <?php echo htmlspecialchars($currentUser['name']); ?></title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="style.css"> <style>
   
    .modal {
      display: none; 
      position: fixed; 
      z-index: 9999; 
      left: 0;
      top: 0;
      width: 100%; 
      height: 100%; 
      background-color: rgba(0,0,0,0.8); 
      backdrop-filter: blur(5px);
    }

    .modal-content {
      background-color: #fff;
      margin: 10% auto; 
      padding: 30px;
      border-radius: 15px;
      width: 90%;
      max-width: 400px;
      text-align: center;
      box-shadow: 0 10px 25px rgba(0,0,0,0.5);
      position: relative;
      animation: slideDown 0.3s ease-out;
      color: #333;
    }

    @keyframes slideDown {
        from { transform: translateY(-50px); opacity: 0; }
        to { transform: translateY(0); opacity: 1; }
    }

    .close-btn {
      color: #aaa;
      float: right;
      font-size: 28px;
      font-weight: bold;
      cursor: pointer;
      position: absolute;
      right: 20px;
      top: 10px;
    }
    .close-btn:hover { color: red; }

    .upgrade-btn {
      background: linear-gradient(135deg, #3f2b96, #E91E63);
      color: white;
      border: none;
      padding: 12px 30px;
      border-radius: 25px;
      font-size: 1rem;
      font-weight: bold;
      cursor: pointer;
      width: 100%;
      margin-top: 20px;
    }
    .upgrade-btn:hover { transform: scale(1.05); }
    .upgrade-btn:disabled { background: #ccc; cursor: not-allowed; opacity: 0.7; }
    
    /* Highlight pentru planul activ */
    .active-plan {
        border: 4px solid #00e676 !important;
        transform: scale(1.05);
        box-shadow: 0 0 20px rgba(0, 230, 118, 0.4);
    }
  </style>
</head>
<body id="top" class="grid-page">

  <div class="grid-container">
    <header>
      <h1>🧠 Smart Planner</h1>
      <p style="font-size: 0.9rem; opacity: 0.8;">Salut, <strong><?php echo htmlspecialchars($currentUser['name']); ?></strong>!</p>
      
      <div style="display: flex; justify-content: center; gap: 10px; align-items: center;">
          <a href="auth_actions.php?logout=true" style="text-decoration: none;">
            <button id="logout-btn" style="background: #E91E63; color: white; border: none; padding: 8px 12px; border-radius: 8px; cursor: pointer; font-weight: bold; font-family: 'Poppins', sans-serif;">Ieși din cont</button>
          </a>
      </div>
    </header>

    <nav>
      <ul>
        <li><a href="index.php" class="active">Task-uri</a></li>
        <li><a href="calendar.php">Calendar</a></li> 
        <li><a href="stats.php">Statistici</a></li>
        <li><a href="about.php">Despre</a></li>
      </ul>
    </nav>

    <main>
      <div class="container">
        <h2>Organizează-ți ziua eficient</h2>
        
        <form action="task_actions.php" method="POST" class="input-main-container">
          <div class="input-row-top">
            <input type="text" name="task_text" id="task-input" placeholder="Scrie un task..." required>
            <input type="date" name="task_deadline" id="task-deadline">
          </div>
          <div class="input-row-bottom">
            <select name="task_category" id="task-category"><option value="Personal">Personal</option><option value="Muncă">Muncă</option><option value="Studii">Studii</option></select>
            <select name="task_priority" id="task-priority"><option value="Low">Low</option><option value="Medium">Medium</option><option value="High">High</option></select>
            <button type="submit" name="add_task" id="add-btn">Adaugă</button>
          </div>
        </form>

        <ul id="task-list">
            <?php if (count($tasks) > 0): ?>
                <?php foreach($tasks as $task): ?>
                    <?php 
                        $borderColor = 'green'; 
                        if($task['priority'] == 'Medium') $borderColor = 'orange';
                        if($task['priority'] == 'High') $borderColor = 'red';
                        $isCompleted = ($task['status'] === 'completed');
                    ?>
                    <li class="<?php echo $isCompleted ? 'completed' : ''; ?>" 
                        style="border-left: 5px solid <?php echo $borderColor; ?>; display: flex; justify-content: space-between; align-items: center; padding: 12px 15px; margin-bottom: 10px; border-radius: 12px; background: #f5f5f5; box-shadow: 0 2px 5px rgba(0,0,0,0.05);">
                        <span style="flex:1;">
                            <strong><?php echo htmlspecialchars($task['title']); ?></strong> <br>
                            <small>📅 <?php echo $task['deadline'] ? $task['deadline'] : 'Azi'; ?> | 📂 <?php echo htmlspecialchars($task['category']); ?> | 🔥 <?php echo htmlspecialchars($task['priority']); ?></small>
                        </span>
                        <div style="display:flex; gap:10px;">
                            <a href="task_actions.php?toggle=<?php echo $task['id']; ?>" style="text-decoration:none; font-size:1.2rem; cursor: pointer;"><?php echo $isCompleted ? '↩️' : '✅'; ?></a>
                            <a href="task_actions.php?delete=<?php echo $task['id']; ?>" onclick="return confirm('Sigur ștergi acest task?')" style="text-decoration:none; font-size:1.2rem; cursor: pointer;">❌</a>
                        </div>
                    </li>
                <?php endforeach; ?>
            <?php else: ?>
                <p style="text-align: center; color: gray; margin-top: 20px;">Nu ai niciun task. Adaugă unul nou! 🚀</p>
            <?php endif; ?>
        </ul>
      </div>

      <section class="plans">
        <h2>Planuri Smart Planner</h2>
        <div class="card-container">
            <div class="card <?php echo ($currentUser['plan'] === 'Basic') ? 'active-plan' : ''; ?>" onclick="openPopup('Basic')">
                <h3>Basic</h3>
                <p>Gratuit</p>
            </div>
            <div class="card <?php echo ($currentUser['plan'] === 'Pro') ? 'active-plan' : ''; ?>" onclick="openPopup('Pro')">
                <h3>Pro</h3>
                <p>Standard</p>
            </div>
            <div class="card <?php echo ($currentUser['plan'] === 'Premium') ? 'active-plan' : ''; ?>" onclick="openPopup('Premium')">
                <h3>Premium</h3>
                <p>Avansat</p>
            </div>
        </div>
      </section>
    </main>

    <aside>
      <div class="xp-card">
        <h3>🏆 Nivelul Tău</h3>
        <div style="background: rgba(0,0,0,0.2); padding: 5px 10px; border-radius: 8px; margin: 10px 0; display: inline-block;">
            <span style="font-size: 0.9rem;">Plan Activ: </span>
            <strong id="user-current-plan" style="color: #00e676; text-transform: uppercase;"><?php echo htmlspecialchars($currentUser['plan'] ?? 'Basic'); ?></strong>
        </div>
        <div class="level-circle"><span><?php echo $currentUser['level'] ?? 1; ?></span></div>
        <p>XP: <span><?php echo $currentUser['xp'] ?? 0; ?></span> / 100</p>
        <div class="xp-bar-container"><div id="xp-bar" class="xp-bar-fill" style="width: <?php echo $xp_percentage; ?>%;"></div></div>
      </div>
      <h3>Notițe rapide</h3>
      <textarea id="notes" placeholder="Scrie aici..."></textarea>
    </aside>

    <footer><p>&copy; 2025 Smart Planner</p></footer>
  </div>
  
  <div id="plan-popup" class="modal">
    <div class="modal-content">
        <span class="close-btn" onclick="closePopup()">&times;</span>
        
        <h2 id="popup-title">Titlu Plan</h2>
        <h3 id="popup-price" style="color: #E91E63; margin: 10px 0;">Preț</h3>
        
        <div style="text-align: left; margin: 20px 0; background: #f9f9f9; padding: 15px; border-radius: 10px;">
            <p style="margin-bottom: 10px;"><strong>Ce primești:</strong></p>
            <ul id="popup-features" style="padding-left: 20px; text-align: left;"></ul>
        </div>

        <form action="upgrade_plan.php" method="POST">
            <input type="hidden" name="plan_name" id="selected-plan-input">
            <button type="submit" id="popup-action-btn" class="upgrade-btn">Activează Planul</button>
        </form>
    </div>
  </div>

  <script>
    // Configurare Date
    const plansData = {
        Basic: { price: "Gratuit", features: ["✅ Acces la Task-uri", "✅ Calendar Simplu", "❌ Fără Statistici Avansate"] },
        Pro: { price: "5€ / lună", features: ["✅ Acces la Task-uri", "✅ Calendar Avansat", "✅ Statistici Detaliate"] },
        Premium: { price: "10€ / lună", features: ["✅ Totul Nelimitat", "✅ Teme Exclusive", "✅ Statistici Pro", "✅ Suport Prioritar"] }
    };

    const modal = document.getElementById("plan-popup");

    // Funcția care se activează la CLICK pe Card
    function openPopup(planName) {
        console.log("Ai dat click pe: " + planName); // Debug în consolă
        const data = plansData[planName];
        if (!data) return;

        // 1. Populăm textele
        document.getElementById("popup-title").innerText = planName + " Plan";
        document.getElementById("popup-price").innerText = data.price;
        document.getElementById("selected-plan-input").value = planName;

        // 2. Facem lista de beneficii
        const list = document.getElementById("popup-features");
        list.innerHTML = "";
        data.features.forEach(feat => {
            let li = document.createElement("li");
            li.innerText = feat;
            list.appendChild(li);
        });

        // 3. Verificăm butonul
        const currentPlan = "<?php echo $currentUser['plan'] ?? 'Basic'; ?>"; // Luăm planul direct din PHP
        const btn = document.getElementById("popup-action-btn");

        if (currentPlan === planName) {
            btn.innerText = "Plan Activ ✅";
            btn.disabled = true;
        } else {
            btn.innerText = `Activează ${planName}`;
            btn.disabled = false;
        }

        // 4. Afișăm Popup-ul
        modal.style.display = "block";
    }

    // Funcția de închidere
    function closePopup() {
        modal.style.display = "none";
    }

    // Închidere la click în afară
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }
  </script>
</body>
</html>