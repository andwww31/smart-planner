<?php session_start(); ?>
<!DOCTYPE html>
<html lang="ro">
<head>
  <meta charset="UTF-8">
  <title>Despre - Smart Planner</title>
  <link rel="stylesheet" href="style.css">
</head>
<body class="grid-page">
  <div class="grid-container">
    <header><h1>ℹ️ Despre Aplicație</h1></header>
    <nav>
      <ul>
        <li><a href="index.php">Task-uri</a></li>
        <li><a href="calendar.php">Calendar</a></li>
        <li><a href="stats.php">Statistici</a></li>
        <li><a href="about.php" class="active">Despre</a></li>
      </ul>
    </nav>
    <main>
      <div class="container">
        <h2 style="color: #3f2b96; border-bottom: 2px solid #eee; padding-bottom: 10px;">
            Smart Planner: Transformă haosul în productivitate 🚀
        </h2>
        
        <p style="font-size: 1.1rem; line-height: 1.6; color: #555;">
            Trăim într-o lume agitată, unde listele de "to do" devin adesea interminabile și stresante. 
            <strong>Smart Planner</strong> a fost creat cu un scop simplu, dar ambițios: să nu fie doar o altă aplicație de notițe, 
            ci un partener digital care te motivează să îți atingi obiectivele. Combinând organizarea riguroasă cu elemente de joc (gamification), 
            aplicația transformă sarcinile plictisitoare în mici victorii zilnice.
        </p>

        <h3 style="margin-top: 30px; color: #333;">✨ Ce face această aplicație specială?</h3>
        
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-top: 15px;">
            
            <div style="background: #e3f2fd; padding: 15px; border-radius: 8px;">
                <h4 style="color: #1565C0;">🧠 Organizare Inteligentă</h4>
                <p style="font-size: 0.9rem;">Nu toate task-urile sunt egale. Setează priorități (High, Medium, Low) și categorii (Muncă, Personal, Studii) pentru a te concentra pe ce contează cu adevărat.</p>
            </div>

            <div style="background: #e8f5e9; padding: 15px; border-radius: 8px;">
                <h4 style="color: #2E7D32;">🎮 Gamification & XP</h4>
                <p style="font-size: 0.9rem;">Productivitatea devine un joc. Fiecare task finalizat îți aduce puncte de experiență (XP). Crește în nivel de la "Începător" la "Maestru" și deblochează satisfacția progresului.</p>
            </div>

            <div style="background: #fff3e0; padding: 15px; border-radius: 8px;">
                <h4 style="color: #EF6C00;">📊 Viziune Clară</h4>
                <p style="font-size: 0.9rem;">Prin Calendarul integrat și pagina de Statistici detaliate, ai mereu o imagine de ansamblu asupra performanței tale și a termenelor limită.</p>
            </div>
        </div>

        <h3 style="margin-top: 30px; color: #333;">🛠️ Despre Proiect</h3>
        <p style="color: #666;">
            Această aplicație este dezvoltată utilizând tehnologii web moderne și robuste. Structura backend este susținută de <strong>PHP</strong> și o bază de date <strong>MySQL</strong> relațională, asigurând securitatea și persistența datelor. Interfața este construită pentru a fi intuitivă și rapidă.
        </p>

        <div style="margin-top: 40px; text-align: center; border-top: 1px solid #eee; padding-top: 20px;">
            <p style="font-style: italic; font-size: 1.2rem; color: #444; margin-bottom: 15px;">
                "Cel mai bun mod de a prezice viitorul este să îl creezi."
            </p>
            
            <p style="font-size: 1.1rem;">
                Dezvoltat de <strong>Paun Ionut-Andrei</strong> 👨‍💻
            </p>
            
            <p style="font-size: 0.8rem; color: #999; margin-top: 5px;">
                Versiunea 1.0.0 | Toate drepturile rezervate.
            </p>
        </div>

      </div>
    </main>
  </div>
</body>
</html>