<?php
session_start();
require 'db.php';

// 1. Dacă userul e deja logat, îl trimitem la pagina principală
if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$mesaj_eroare = "";
$mesaj_succes = "";

// 2. VERIFICĂM DACĂ S-A APĂSAT BUTONUL "ÎNREGISTREAZĂ-TE"
if (isset($_POST['register'])) {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    // Verificăm dacă câmpurile sunt completate
    if (!empty($name) && !empty($email) && !empty($password)) {
        
        // A. Verificăm dacă emailul există deja în baza de date
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        
        if ($stmt->fetch()) {
            $mesaj_eroare = "Acest email este deja folosit!";
        } else {
            // B. Criptăm parola
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            
            // C. Inserăm utilizatorul (XP, Level și Plan se pun automat Default din baza de date)
            $sql = "INSERT INTO users (name, email, password) VALUES (?, ?, ?)";
            $stmt = $pdo->prepare($sql);

            if ($stmt->execute([$name, $email, $hashedPassword])) {
                // Succes! Redirecționăm la login cu mesaj
                header("Location: login.php?msg=account_created");
                exit();
            } else {
                $mesaj_eroare = "Eroare la baza de date. Încearcă din nou.";
            }
        }
    } else {
        $mesaj_eroare = "Te rog completează toate câmpurile!";
    }
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sign Up - Smart Planner</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

  <nav class="navbar">
    <h2>Smart Planner</h2>
    <ul>
      <li><a href="login.php">Login</a></li>
    </ul>
  </nav>

  <div class="container">
    <h1>Creează cont</h1>
    
    <?php if ($mesaj_eroare != ""): ?>
        <p style="color: red; text-align: center; background: #ffe6e6; padding: 10px; border-radius: 5px;">
            <?php echo $mesaj_eroare; ?>
        </p>
    <?php endif; ?>

    <form action="" method="POST" id="signupForm">
        <div class="input-group" style="flex-direction: column;">
            <input type="text" name="name" placeholder="Nume complet" required style="width:100%">
            
            <input type="email" name="email" placeholder="Email" required style="width:100%">
            
            <input type="password" name="password" placeholder="Parolă" required style="width:100%">
            
            <button type="submit" name="register" style="width:100%">Înregistrează-te</button>
        </div>
    </form>

    <p style="margin-top:15px;">Ai deja cont? <a href="login.php">Loghează-te</a>.</p>
  </div>

  </body>
</html>