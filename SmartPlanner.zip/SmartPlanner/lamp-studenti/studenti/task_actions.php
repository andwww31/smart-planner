<?php
session_start();
require 'db.php';

// Verificăm dacă userul e logat
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// 1. ADĂUGARE TASK
if (isset($_POST['add_task'])) {
    $text = trim($_POST['task_text']);
    $deadline = !empty($_POST['task_deadline']) ? $_POST['task_deadline'] : NULL;
    $category = $_POST['task_category'];
    $priority = $_POST['task_priority'];

    if (!empty($text)) {
        $stmt = $pdo->prepare("INSERT INTO tasks (user_id, title, deadline, category, priority) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$user_id, $text, $deadline, $category, $priority]);
    }
    header("Location: index.php");
    exit();
}

// 2. ȘTERGERE TASK
if (isset($_GET['delete'])) {
    $task_id = $_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM tasks WHERE id = ? AND user_id = ?");
    $stmt->execute([$task_id, $user_id]);
    header("Location: index.php");
    exit();
}

// 3. FINALIZARE TASK (+XP)
if (isset($_GET['toggle'])) {
    $task_id = $_GET['toggle'];

    // Vedem statusul curent
    $stmt = $pdo->prepare("SELECT status FROM tasks WHERE id = ? AND user_id = ?");
    $stmt->execute([$task_id, $user_id]);
    $task = $stmt->fetch();

    if ($task) {
        // Inversăm statusul (dacă e completed devine pending și invers)
        $new_status = ($task['status'] === 'completed') ? 'pending' : 'completed';
        
        $update = $pdo->prepare("UPDATE tasks SET status = ? WHERE id = ?");
        $update->execute([$new_status, $task_id]);

        // Dăm XP doar dacă l-a finalizat
        if ($new_status === 'completed') {
            $updateUser = $pdo->prepare("UPDATE users SET xp = xp + 10 WHERE id = ?");
            $updateUser->execute([$user_id]);
            
            // Verificăm Level UP (simplificat)
            $pdo->query("UPDATE users SET level = level + 1, xp = xp - 100 WHERE id = $user_id AND xp >= 100");
        }
    }
    header("Location: index.php");
    exit();
}
?>