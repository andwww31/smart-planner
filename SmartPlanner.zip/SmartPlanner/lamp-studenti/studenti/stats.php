<?php
// Activăm afișarea erorilor pentru siguranță
ini_set('display_errors', 1);
error_reporting(E_ALL);

ob_start();
session_start();
require 'db.php';

if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }

$user_id = $_SESSION['user_id'];

try {
    // AICI ERA PROBLEMA: Am schimbat alias-ul din 'high_priority' în 'total_high'
    $stmt = $pdo->prepare("SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
        SUM(CASE WHEN priority = 'High' THEN 1 ELSE 0 END) as total_high
        FROM tasks WHERE user_id = ?");
    
    $stmt->execute([$user_id]);
    $stats = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$stats) {
        $total = 0; $completed = 0; $high_priority_count = 0;
    } else {
        $total = $stats['total'];
        $completed = $stats['completed'] ?? 0;
        // Preluăm noua denumire
        $high_priority_count = $stats['total_high'] ?? 0;
    }

    $pending = $total - $completed;
    $completionRate = ($total > 0) ? round(($completed / $total) * 100) : 0;

} catch (Exception $e) {
    die("<h2 style='color:red'>Eroare SQL:</h2> " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
  <meta charset="UTF-8">
  <title>Statistici - Smart Planner</title>
  <link rel="stylesheet" href="style.css">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="grid-page">
  <div class="grid-container">
    <header>
      <h1>📊 Statistici</h1>
      <a href="index.php" style="color: white; text-decoration: none; border: 1px solid white; padding: 5px 10px; border-radius: 5px;">⬅ Înapoi</a>
    </header>

    <nav>
      <ul>
        <li><a href="index.php">Task-uri</a></li>
        <li><a href="calendar.php">Calendar</a></li>
        <li><a href="stats.php" class="active">Statistici</a></li>
        <li><a href="about.php">Despre</a></li>
      </ul>
    </nav>

    <main>
      <div class="container">
        
        <div style="display: flex; gap: 20px; margin-bottom: 30px; flex-wrap: wrap; justify-content: center;">
            <div class="card" style="flex: 1; min-width: 150px; text-align: center; background: #e3f2fd; border: none; padding: 20px;">
                <h3>Total</h3>
                <h1 style="color: #1976D2; font-size: 3rem; margin: 10px 0;"><?php echo $total; ?></h1>
            </div>

            <div class="card" style="flex: 1; min-width: 150px; text-align: center; background: #e8f5e9; border: none; padding: 20px;">
                <h3>Finalizate</h3>
                <h1 style="color: #388E3C; font-size: 3rem; margin: 10px 0;"><?php echo $completed; ?></h1>
            </div>

            <div class="card" style="flex: 1; min-width: 150px; text-align: center; background: #ffebee; border: none; padding: 20px;">
                <h3>Prioritate High</h3>
                <h1 style="color: #D32F2F; font-size: 3rem; margin: 10px 0;"><?php echo $high_priority_count; ?></h1>
            </div>
        </div>

        <h3 style="text-align:center;">Progres Vizual</h3>
        
        <?php if($total == 0): ?>
            <p style="text-align:center; color:gray;">Nu ai task-uri. <a href="index.php">Adaugă unul!</a></p>
        <?php else: ?>
            <div style="max-width: 400px; margin: 0 auto; position: relative; height: 300px;">
                <canvas id="myChart"></canvas>
            </div>
        <?php endif; ?>

      </div>
    </main>
  </div>

  <?php if($total > 0): ?>
  <script>
    document.addEventListener("DOMContentLoaded", function() {
        const ctx = document.getElementById('myChart');
        if(ctx) {
            new Chart(ctx, {
              type: 'doughnut',
              data: {
                labels: ['Finalizate', 'De făcut'],
                datasets: [{
                  data: [<?php echo $completed; ?>, <?php echo $pending; ?>],
                  backgroundColor: ['#4caf50', '#ff9800'],
                  borderWidth: 2,
                  borderColor: '#ffffff'
                }]
              },
              options: {
                responsive: true,
                maintainAspectRatio: false
              }
            });
        }
    });
  </script>
  <?php endif; ?>

</body>
</html>