<?php
session_start(); // Pornim sesiunea pentru a putea loga utilizatorul
require 'db.php';

// 1. Dacă utilizatorul este deja logat, îl trimitem la pagina principală
if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$mesaj_eroare = "";
$mesaj_succes = "";

// Verificăm dacă venim de la Sign Up cu mesaj de succes
if (isset($_GET['msg']) && $_GET['msg'] == 'account_created') {
    $mesaj_succes = "Cont creat cu succes! Te poți loga.";
}

// 2. PROCESARE LOGIN
if (isset($_POST['login'])) {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    // Căutăm utilizatorul în baza de date
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    // Verificăm parola
    if ($user && password_verify($password, $user['password'])) {
        // --- LOGARE REUȘITĂ ---
        
        // Salvăm datele esențiale în sesiune
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['name'];
        $_SESSION['user_email'] = $user['email'];
        
        // Salvăm datele de GAMIFICATION (pentru bara de progres)
        $_SESSION['xp'] = $user['xp'];
        $_SESSION['level'] = $user['level'];
        $_SESSION['plan'] = $user['plan'];

        // Redirecționăm către aplicație
        header("Location: index.php");
        exit();
    } else {
        $mesaj_eroare = "Email sau parolă incorectă!";
    }
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login - Smart Planner</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

  <nav class="navbar">
    <h2>Smart Planner</h2>
    <ul>
      <li><a href="signup.php">Sign Up</a></li>
    </ul>
  </nav>

  <div class="container">
    <h1>Logare</h1>

    <?php if ($mesaj_eroare != ""): ?>
        <p style="color: red; text-align: center; background: #ffe6e6; padding: 10px; border-radius: 5px;">
            <?php echo $mesaj_eroare; ?>
        </p>
    <?php endif; ?>

    <?php if ($mesaj_succes != ""): ?>
        <p style="color: green; text-align: center; background: #e6ffe6; padding: 10px; border-radius: 5px;">
            <?php echo $mesaj_succes; ?>
        </p>
    <?php endif; ?>

    <form action="" method="POST" id="loginForm">
      <div class="input-group" style="flex-direction: column;">
          <input type="email" name="email" placeholder="Email" required style="width:100%">
          
          <input type="password" name="password" placeholder="Parolă" required style="width:100%">
          
          <button type="submit" name="login" style="width:100%">Intră în cont</button>
      </div>
    </form>

    <p style="margin-top:15px;">Nu ai cont? <a href="signup.php">Creează unul aici</a>.</p>
  </div>

  </body>
</html>